#ifndef MP_RENDEZVOUS_H_
#define MP_RENDEZVOUS_H_

#include <stdint.h>

intptr_t mp_rendezvous(void *tag, intptr_t value);

#endif
